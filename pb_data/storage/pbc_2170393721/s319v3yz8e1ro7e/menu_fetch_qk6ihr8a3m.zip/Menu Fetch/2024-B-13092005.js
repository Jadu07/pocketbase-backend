async function fetchMenu() {
    try {
        const response = await fetch('http://50.50.50.115:3000/api/menu');
        return await response.json();
    } catch (error) {
        console.error('Error fetching menu:', error);
        return [];
    }
}

async function menu() {
    console.log("Welcome to our restaurant!");
    const data = await fetchMenu();
    console.log("Today's Menu:");
    data.forEach(item => {
        console.log(`ID: ${item.id} | Name: ${item.itemName} | Available: ${item.availableQuantity} | Price: $${item.price}`);
    });

    let itemId = parseInt(prompt("Enter the item ID you want to order:"));
    let selectedItem = data.find(item => item.id === itemId);
    if (!selectedItem) {
        alert("Invalid item ID. Please try again.");
        return;
    }
    let quantity = parseInt(prompt("Enter the quantity you want to order:"));
    if (quantity > selectedItem.availableQuantity || quantity <= 0) {
        alert("Invalid quantity. Please try again.");
        return;
    }
    let customerName = prompt("Enter your name:");
    alert(`Thank you, ${customerName}! Your order for ${quantity} ${selectedItem.itemName}(s) has been placed.`);
    console.log("Placing your order...");
    console.log("Order placed successfully!");
    console.log('Order is ready! Thank you for shopping with us!');
}

async function displayOrders() {
    try {
        const response = await fetch('http://50.50.50.115:3000/api/orders');
        const orders = await response.json();
        console.log('List of Orders:');
        orders.forEach(order => {
            console.log(`Customer: ${order.customerName} | Item ID: ${order.itemId} | Quantity: ${order.quantity}`);
        });
    } catch (error) {
        console.error('Error fetching orders:', error);
    }
}





